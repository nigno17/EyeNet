%% network error
close
clear

abs_train_tr3_te1 = importdata('abs_list_tr3_te1.txt');
abs_val_tr3_te1 = importdata('abs_list_val_tr3_te1.txt');

abs_train_tr3 = importdata('abs_list_tr3.txt');
abs_val_tr3 = importdata('abs_list_val_tr3.txt');

line_width = 3;
epochs = 200;

figure('units','normalized','outerposition',[0 0 1 1])
plot(abs_train_tr3_te1(1:epochs), 'b--', 'LineWidth', line_width)
hold on
plot(abs_val_tr3_te1(1:epochs), 'b', 'LineWidth', line_width)

plot(abs_train_tr3(1:epochs), 'r--', 'LineWidth', line_width)
plot(abs_val_tr3(1:epochs), 'r', 'LineWidth', line_width)

title('Euclidian distance', 'FontSize', 25)
xlabel('Epochs', 'FontSize', 20)
ylabel('Distance (m)', 'FontSize', 20)
legend({'Train (trainSet + 0.1% testSet)','Val (trainSet + 0.1% testSet)', ...
       'Train (trainSet)','Val (trainSet)'}, 'FontSize',20)
axis([0 epochs 0 0.2])
set(gca, 'FontSize', 20)
grid on

%% prediction results single axis 

predictions = importdata('predictions_tr3.txt');
ground_truth = importdata('ground_truth_tr3.txt');

pred_len = length(predictions);

figure('units','normalized','outerposition',[0 0 1 1])
plot(predictions(:, 1), 'b--', 'LineWidth', line_width)
hold on
plot(ground_truth(:, 1), 'r', 'LineWidth', line_width)

title('X axis', 'FontSize', 25)
xlabel('Dataset elements', 'FontSize', 20)
ylabel('Position (m)', 'FontSize', 20)
legend({'Predictions','Ground truth'}, 'FontSize',20)
axis([0 pred_len 0 0.6])
set(gca, 'FontSize', 20)
grid on

figure('units','normalized','outerposition',[0 0 1 1])
plot(predictions(:, 2), 'b--', 'LineWidth', line_width)
hold on
plot(ground_truth(:, 2), 'r', 'LineWidth', line_width)

title('Y axis', 'FontSize', 25)
xlabel('Dataset elements', 'FontSize', 20)
ylabel('Position (m)', 'FontSize', 20)
legend({'Predictions','Ground truth'}, 'FontSize',20)
axis([0 pred_len 0 0.6])
set(gca, 'FontSize', 20)
grid on

figure('units','normalized','outerposition',[0 0 1 1])
plot(predictions(:, 3), 'b--', 'LineWidth', line_width)
hold on
plot(ground_truth(:, 3), 'r', 'LineWidth', line_width)

title('Z axis', 'FontSize', 25)
xlabel('Dataset elements', 'FontSize', 20)
ylabel('Position (m)', 'FontSize', 20)
legend({'Predictions','Ground truth'}, 'FontSize',20)
axis([0 pred_len 0 0.6])
set(gca, 'FontSize', 20)
grid on

%% prediction results 3D 

% Set up the movie.
writerObj = VideoWriter('out2.avi'); % Name it.
writerObj.FrameRate = 120; % How many frames per second.
open(writerObj); 

figure('units','normalized','outerposition',[0 0 1 1])
    
 for i = 1:(pred_len - 1)
     time_elapsed = i+1;
     plot3(predictions(1:time_elapsed, 1), predictions(1:time_elapsed, 2), predictions(1:time_elapsed, 3), 'b--', 'LineWidth', line_width)
     hold on
     plot3(ground_truth(1:time_elapsed, 1), ground_truth(1:time_elapsed, 2), ground_truth(1:time_elapsed, 3), 'r', 'LineWidth', line_width)
     
     title('Predictions vs Ground truth', 'FontSize', 25)
     xlabel('x (m)', 'FontSize', 20)
     ylabel('y (m)', 'FontSize', 20)
     zlabel('z (m)', 'FontSize', 20)
     legend({'Predictions','Ground truth'}, 'FontSize',20)
     axis([0 0.6 0 0.6 0 0.6])
     set(gca, 'FontSize', 20)
     grid on
     
     frame = getframe(gcf);
     writeVideo(writerObj, frame);
     
     hold off
     
     %pause(0.001)
 end
 
 close(writerObj);